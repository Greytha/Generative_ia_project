# =============================
# 1️⃣ Installer les librairies
# =============================
!pip install -q transformers datasets

# =============================
# 2️⃣ Importer les modules
# =============================
from datasets import load_dataset
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, pipeline, TextClassificationPipeline

# =============================
# 3️⃣ Charger et préparer le dataset
# =============================
dataset = load_dataset("csv", data_files="/content/dataset.csv")

# Convertir labels en 0 = non-toxic, 1 = toxic
def encode_label(example):
    example['label'] = 1 if example['label'].lower() == 'toxic' else 0
    return example

dataset = dataset.map(encode_label)

# =============================
# 4️⃣ Tokenisation
# =============================
model_name = "distilbert-base-uncased"
tokenizer = AutoTokenizer.from_pretrained(model_name)

def tokenize(batch):
    return tokenizer(batch['text'], padding=True, truncation=True, max_length=128)

dataset = dataset.map(tokenize, batched=True)
dataset.set_format('torch', columns=['input_ids', 'attention_mask', 'label'])

# =============================
# 5️⃣ Créer le modèle pour 2 labels
# =============================
model = AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=2)

# =============================
# 6️⃣ Configurer le Trainer
# =============================
training_args = TrainingArguments(
    output_dir="./toxic-finetuned",
    learning_rate=2e-5,
    per_device_train_batch_size=8,
    num_train_epochs=3,
    save_strategy="epoch",
    logging_dir='./logs',
    logging_steps=10,
    report_to="none"  # Désactive W&B
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset['train'],
    eval_dataset=dataset['train']
)

# =============================
# 7️⃣ Entraîner le modèle
# =============================
trainer.train()

# =============================
# 8️⃣ Créer les pipelines
# =============================

# Pipeline émotion
emotion_classifier = pipeline(
    "text-classification",
    model="j-hartmann/emotion-english-distilroberta-base",
    return_all_scores=True
)

# Pipeline toxicité : modèle fine-tuné via TextClassificationPipeline
toxicity_model = TextClassificationPipeline(
    model=trainer.model,
    tokenizer=tokenizer,
    return_all_scores=True
)

toxicity_models = [
    toxicity_model,
    pipeline("text-classification", model="cardiffnlp/twitter-roberta-base-offensive", return_all_scores=True)
]

# =============================
# 9️⃣ Fonction d'analyse d'un texte corrigée
# =============================
def analyser_texte(texte, seuil=0.6, consensus=2):
    """
    seuil : score minimum pour considérer un texte comme toxique/offensive
    consensus : nombre de modèles qui doivent être d'accord pour bloquer
    """
    # Emotion
    resultat_emotion = emotion_classifier(texte)[0]
    emotion_dominante = max(resultat_emotion, key=lambda x: x['score'])

    # Toxicité
    blocage = False
    details_hate = []
    scores_block = 0

    for model in toxicity_models:
        resultat = model(texte)[0]
        # Corriger LABEL_0/LABEL_1 pour le modèle fine-tuné
        for r in resultat:
            if r['label'] == 'LABEL_0':
                r['label'] = 'non-toxic'
            elif r['label'] == 'LABEL_1':
                r['label'] = 'toxic'
        top_label = max(resultat, key=lambda x: x['score'])
        details_hate.append((top_label['label'], top_label['score']))
        if top_label['score'] > seuil and top_label['label'].lower() not in ['non-toxic', 'non-offensive', 'none']:
            scores_block += 1

    # Blocage seulement si consensus atteint
    blocage = scores_block >= consensus

    # Affichage
    print("Write your comment :", texte)
    print("Émotion dominante :", emotion_dominante['label'], "avec un score de", round(emotion_dominante['score'], 3))
    for label, score in details_hate:
        print("Modèle détecte :", label, "avec un score de", round(score, 3))
    print("Comment to block ?", "Yes" if blocage else "No")
    print("------")

# =============================
# 10️⃣ Tester un texte en boucle
# =============================
while True:
    texte_utilisateur = input("Entrez un texte (ou 'exit' pour quitter) : ")
    if texte_utilisateur.lower() == "exit":
        break
    analyser_texte(texte_utilisateur)
