import requests
import json

def test_moderation_api():
    """Test the moderation API with various text samples"""
    
    # Test cases with different types of content
    test_cases = [
        {
            "text": "Hello everyone! Hope you're having a great day!",
            "expected": "non-toxic"
        },
        {
            "text": "I hate this stupid thing, it's completely useless!",
            "expected": "toxic"
        },
        {
            "text": "The weather forecast says it will be sunny tomorrow.",
            "expected": "non-toxic"
        },
        {
            "text": "You're an idiot and I hope you fail miserably!",
            "expected": "toxic"
        },
        {
            "text": "Thanks for sharing this helpful information!",
            "expected": "non-toxic"
        }
    ]
    
    print("🧪 Testing AI Moderation API")
    print("=" * 50)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\nTest {i}: {test_case['text'][:50]}...")
        print(f"Expected: {test_case['expected']}")
        
        try:
            # Simulate API call (in real scenario, this would be an HTTP request)
            # For now, we'll use the moderation service directly
            from subprocess import run, PIPE
            
            # Create a temporary test file
            with open('/tmp/test_text.txt', 'w') as f:
                f.write(test_case['text'])
            
            # Run the moderation service
            result = run(['python', 'scripts/ai-moderation-service.py', test_case['text']], 
                        capture_output=True, text=True)
            
            if result.returncode == 0:
                print(f"✅ API Response: {result.stdout.strip()}")
            else:
                print(f"❌ Error: {result.stderr.strip()}")
                
        except Exception as e:
            print(f"❌ Exception: {str(e)}")
    
    print("\n" + "=" * 50)
    print("✅ API Testing Complete!")

if __name__ == "__main__":
    test_moderation_api()
