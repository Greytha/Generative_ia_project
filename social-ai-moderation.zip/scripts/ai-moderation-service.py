# =============================
# Service de modération IA - Version Production
# Basé sur votre modèle fine-tuné DistilBERT
# =============================

import json
import sys
from transformers import AutoTokenizer, AutoModelForSequenceClassification, pipeline, TextClassificationPipeline
import torch
import requests
import pandas as pd
from io import StringIO

class ModerationService:
    def __init__(self):
        self.model_name = "distilbert-base-uncased"
        self.tokenizer = None
        self.toxicity_model = None
        self.emotion_classifier = None
        self.toxicity_models = []
        self.setup_models()
    
    def setup_models(self):
        """Initialise tous les modèles nécessaires"""
        try:
            # Tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            
            # Modèle d'émotion
            self.emotion_classifier = pipeline(
                "text-classification",
                model="j-hartmann/emotion-english-distilroberta-base",
                return_all_scores=True
            )
            
            # Pour la démo, on utilise des modèles pré-entraînés
            # Dans votre cas réel, vous chargeriez votre modèle fine-tuné depuis ./toxic-finetuned
            self.toxicity_models = [
                pipeline("text-classification", model="unitary/toxic-bert", return_all_scores=True),
                pipeline("text-classification", model="cardiffnlp/twitter-roberta-base-offensive", return_all_scores=True)
            ]
            
            print("✅ Modèles chargés avec succès")
            
        except Exception as e:
            print(f"❌ Erreur lors du chargement des modèles: {e}")
            # Fallback vers des modèles plus simples
            self.setup_fallback_models()
    
    def setup_fallback_models(self):
        """Modèles de secours si les principaux ne se chargent pas"""
        try:
            self.emotion_classifier = pipeline("sentiment-analysis", return_all_scores=True)
            self.toxicity_models = [
                pipeline("text-classification", model="martin-ha/toxic-comment-model", return_all_scores=True)
            ]
            print("✅ Modèles de secours chargés")
        except:
            print("❌ Impossible de charger les modèles")
    
    def load_dataset_from_url(self, url):
        """Charge le dataset depuis l'URL fournie"""
        try:
            response = requests.get(url)
            response.raise_for_status()
            
            # Lire le CSV
            df = pd.read_csv(StringIO(response.text))
            print(f"✅ Dataset chargé: {len(df)} exemples")
            print(f"Colonnes: {df.columns.tolist()}")
            print(f"Distribution des labels: {df['label'].value_counts().to_dict()}")
            
            return df
        except Exception as e:
            print(f"❌ Erreur lors du chargement du dataset: {e}")
            return None
    
    def analyser_texte(self, texte, seuil=0.6, consensus=2):
        """
        Analyse un texte selon votre méthode originale
        seuil : score minimum pour considérer un texte comme toxique
        consensus : nombre de modèles qui doivent être d'accord pour bloquer
        """
        try:
            # Analyse d'émotion
            resultat_emotion = self.emotion_classifier(texte)
            if isinstance(resultat_emotion[0], list):
                resultat_emotion = resultat_emotion[0]
            
            emotion_dominante = max(resultat_emotion, key=lambda x: x['score'])
            
            # Analyse de toxicité avec consensus
            blocage = False
            details_hate = []
            scores_block = 0
            
            for model in self.toxicity_models:
                try:
                    resultat = model(texte)
                    if isinstance(resultat[0], list):
                        resultat = resultat[0]
                    
                    # Normaliser les labels
                    for r in resultat:
                        if r['label'] in ['LABEL_0', 'NOT_TOXIC', 'CLEAN']:
                            r['label'] = 'non-toxic'
                        elif r['label'] in ['LABEL_1', 'TOXIC', 'OFFENSIVE']:
                            r['label'] = 'toxic'
                    
                    top_label = max(resultat, key=lambda x: x['score'])
                    details_hate.append((top_label['label'], top_label['score']))
                    
                    if (top_label['score'] > seuil and 
                        top_label['label'].lower() not in ['non-toxic', 'non-offensive', 'none', 'clean']):
                        scores_block += 1
                        
                except Exception as e:
                    print(f"Erreur avec un modèle de toxicité: {e}")
                    continue
            
            # Décision finale basée sur le consensus
            blocage = scores_block >= consensus
            
            return {
                "text": texte,
                "toxicity": {
                    "score": max([score for _, score in details_hate]) if details_hate else 0.0,
                    "label": "toxic" if blocage else "non-toxic",
                    "shouldBlock": blocage,
                    "details": details_hate
                },
                "emotion": {
                    "label": emotion_dominante['label'],
                    "score": emotion_dominante['score']
                },
                "moderation": {
                    "blocked": blocage,
                    "reason": "Contenu potentiellement toxique détecté par consensus" if blocage else None,
                    "confidence": max([score for _, score in details_hate]) if details_hate else 0.0,
                    "consensus": scores_block,
                    "required_consensus": consensus
                }
            }
            
        except Exception as e:
            print(f"❌ Erreur lors de l'analyse: {e}")
            return {
                "text": texte,
                "error": str(e),
                "toxicity": {"score": 0.0, "label": "unknown", "shouldBlock": False},
                "emotion": {"label": "unknown", "score": 0.0},
                "moderation": {"blocked": False, "reason": "Erreur d'analyse"}
            }

# Point d'entrée pour l'API
if __name__ == "__main__":
    try:
        # Initialiser le service
        service = ModerationService()
        
        # Charger le dataset pour validation
        dataset_url = "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dataset%201-DeTh37tJrdFwlQise1PJ1ULWfhBngU.csv"
        dataset = service.load_dataset_from_url(dataset_url)
        
        # Lire le texte depuis stdin (envoyé par l'API Node.js)
        input_data = sys.stdin.read()
        data = json.loads(input_data)
        
        text = data.get('text', '')
        seuil = data.get('threshold', 0.6)
        consensus = data.get('consensus', 2)
        
        # Analyser le texte
        result = service.analyser_texte(text, seuil, consensus)
        
        # Retourner le résultat en JSON
        print(json.dumps(result, ensure_ascii=False))
        
    except Exception as e:
        error_result = {
            "error": str(e),
            "text": "",
            "toxicity": {"score": 0.0, "label": "error", "shouldBlock": False},
            "emotion": {"label": "error", "score": 0.0},
            "moderation": {"blocked": False, "reason": f"Erreur système: {str(e)}"}
        }
        print(json.dumps(error_result, ensure_ascii=False))
