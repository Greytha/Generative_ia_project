"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Heart, MessageCircle, Share2, MoreHorizontal, Shield } from "lucide-react"
import { CommentSection } from "@/components/comment-section"
import { Badge } from "@/components/ui/badge"

interface Comment {
  id: number
  author: string
  avatar: string
  content: string
  timestamp: string
  isModerated: boolean
}

interface Post {
  id: number
  author: string
  avatar: string
  timestamp: string
  content: string
  likes: number
  comments: Comment[]
}

interface PostCardProps {
  post: Post
  onComment: (postId: number, content: string, isModerated: boolean) => void
}

export function PostCard({ post, onComment }: PostCardProps) {
  const [liked, setLiked] = useState(false)
  const [showComments, setShowComments] = useState(false)

  return (
    <Card className="shadow-sm border-0 bg-white/80 backdrop-blur-sm animate-slide-in hover:shadow-md transition-all duration-200">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-11 w-11 ring-2 ring-emerald-100">
              <AvatarImage src={post.avatar || "/placeholder.svg"} alt={post.author} />
              <AvatarFallback className="bg-emerald-100 text-emerald-700 font-medium">
                {post.author.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-semibold text-gray-900">{post.author}</h3>
                <Badge variant="outline" className="text-xs text-emerald-700 border-emerald-300 bg-emerald-50">
                  <Shield className="h-3 w-3 mr-1" />
                  Vérifié
                </Badge>
              </div>
              <p className="text-sm text-gray-500">{post.timestamp}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="prose prose-sm max-w-none">
          <p className="text-gray-800 leading-relaxed text-pretty">{post.content}</p>
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-gray-200">
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLiked(!liked)}
              className={`hover:bg-red-50 hover:text-red-600 transition-colors ${
                liked ? "text-red-600 bg-red-50" : "text-gray-500"
              }`}
            >
              <Heart className={`h-4 w-4 mr-1.5 ${liked ? "fill-current" : ""}`} />
              <span className="font-medium">{post.likes + (liked ? 1 : 0)}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="hover:bg-blue-50 hover:text-blue-600 transition-colors text-gray-500"
            >
              <MessageCircle className="h-4 w-4 mr-1.5" />
              <span className="font-medium">{post.comments.length}</span>
            </Button>

            <Button
              variant="ghost"
              size="sm"
              className="hover:bg-green-50 hover:text-green-600 transition-colors text-gray-500"
            >
              <Share2 className="h-4 w-4 mr-1.5" />
              <span className="font-medium">Partager</span>
            </Button>
          </div>
        </div>

        {showComments && (
          <div className="animate-slide-in">
            <CommentSection postId={post.id} comments={post.comments} onComment={onComment} />
          </div>
        )}
      </CardContent>
    </Card>
  )
}
