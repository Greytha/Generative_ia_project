"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Send, Sparkles, User } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

interface CreatePostProps {
  onSubmit: (content: string) => void
}

export function CreatePost({ onSubmit }: CreatePostProps) {
  const [content, setContent] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (content.trim()) {
      onSubmit(content)
      setContent("")
    }
  }

  return (
    <Card className="shadow-sm border-0 bg-card/50 backdrop-blur-sm animate-slide-in">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src="/user-profile-illustration.png" alt="Votre profil" />
            <AvatarFallback>
              <User className="h-5 w-5" />
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="font-medium text-foreground">Créer un post</h3>
            <p className="text-sm text-muted-foreground">Partagez vos idées avec la communauté</p>
          </div>
          <div className="flex items-center gap-1 text-xs text-primary bg-primary/10 px-2 py-1 rounded-full">
            <Sparkles className="h-3 w-3" />
            <span>IA Protégé</span>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Textarea
            placeholder="Quoi de neuf ? Partagez vos pensées, découvertes ou questions..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="min-h-[120px] resize-none border-0 bg-muted/30 focus:bg-background transition-colors text-base leading-relaxed"
          />
          <div className="flex items-center justify-between">
            <div className="text-xs text-muted-foreground">
              {content.length > 0 && (
                <span className={content.length > 280 ? "text-destructive" : ""}>{content.length}/280 caractères</span>
              )}
            </div>
            <Button
              type="submit"
              disabled={!content.trim() || content.length > 280}
              className="bg-primary hover:bg-primary/90 shadow-sm"
            >
              <Send className="h-4 w-4 mr-2" />
              Publier
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
