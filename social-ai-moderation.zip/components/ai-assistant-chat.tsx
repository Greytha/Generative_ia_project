"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Send, X, Bot, Shield, AlertTriangle, CheckCircle, Minimize2, Maximize2 } from "lucide-react"

interface Message {
  id: number
  content: string
  isUser: boolean
  timestamp: string
  analysis?: {
    isSafe: boolean
    confidence: number
    suggestions?: string[]
  }
}

interface AIAssistantChatProps {
  isOpen: boolean
  onToggle: () => void
}

export default function AIAssistantChat({ isOpen, onToggle }: AIAssistantChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      content:
        "Salut ! Je suis votre assistant IA SafeChat. Je peux vous aider à vérifier si vos commentaires sont appropriés avant de les publier. Tapez votre message et je l'analyserai pour vous !",
      isUser: false,
      timestamp: "Maintenant",
    },
  ])
  const [inputMessage, setInputMessage] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)

  const analyzeMessage = async (message: string) => {
    // Simulation de l'analyse IA (remplacer par votre vraie API)
    const toxicKeywords = ["hate", "stupid", "idiot", "kill", "die", "ugly", "loser"]
    const lowerMessage = message.toLowerCase()

    const hasToxicContent = toxicKeywords.some((keyword) => lowerMessage.includes(keyword))
    const confidence = hasToxicContent ? Math.random() * 0.3 + 0.7 : Math.random() * 0.2 + 0.8

    let suggestions = []
    if (hasToxicContent) {
      suggestions = [
        "Essayez de reformuler de manière plus constructive",
        "Concentrez-vous sur les idées plutôt que sur les personnes",
        "Utilisez un ton plus respectueux",
      ]
    } else {
      suggestions = ["Votre message semble approprié !", "Bon ton et contenu constructif", "Prêt à être publié"]
    }

    return {
      isSafe: !hasToxicContent,
      confidence: Math.round(confidence * 100),
      suggestions,
    }
  }

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return

    const userMessage: Message = {
      id: messages.length + 1,
      content: inputMessage,
      isUser: true,
      timestamp: "Maintenant",
    }

    setMessages((prev) => [...prev, userMessage])
    setInputMessage("")
    setIsAnalyzing(true)

    // Analyser le message
    const analysis = await analyzeMessage(inputMessage)

    setTimeout(() => {
      const aiResponse: Message = {
        id: messages.length + 2,
        content: analysis.isSafe
          ? `✅ Votre message semble approprié ! Confiance: ${analysis.confidence}%`
          : `⚠️ Attention, ce message pourrait être problématique. Confiance: ${analysis.confidence}%`,
        isUser: false,
        timestamp: "Maintenant",
        analysis,
      }

      setMessages((prev) => [...prev, aiResponse])
      setIsAnalyzing(false)
    }, 1500)
  }

  if (!isOpen) {
    return (
      <Button
        onClick={onToggle}
        className="fixed bottom-6 right-6 w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 shadow-lg z-50"
      >
        <Bot className="w-6 h-6" />
      </Button>
    )
  }

  return (
    <Card
      className={`fixed bottom-6 right-6 w-96 shadow-2xl border-0 bg-white/95 backdrop-blur-sm z-50 transition-all duration-300 ${
        isMinimized ? "h-16" : "h-[500px]"
      }`}
    >
      <CardHeader className="p-4 bg-gradient-to-r from-emerald-500 to-teal-500 text-white rounded-t-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Avatar className="w-8 h-8 bg-white/20">
              <AvatarFallback className="bg-transparent text-white">
                <Bot className="w-4 h-4" />
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-sm">Assistant IA SafeChat</CardTitle>
              <p className="text-xs opacity-90">Vérification de contenu</p>
            </div>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMinimized(!isMinimized)}
              className="text-white hover:bg-white/20 w-8 h-8 p-0"
            >
              {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={onToggle} className="text-white hover:bg-white/20 w-8 h-8 p-0">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>

      {!isMinimized && (
        <>
          <CardContent className="flex-1 p-4 overflow-y-auto max-h-80">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] p-3 rounded-lg ${
                      message.isUser ? "bg-emerald-500 text-white" : "bg-gray-100 text-gray-800"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    {message.analysis && (
                      <div className="mt-3 space-y-2">
                        <div className="flex items-center gap-2">
                          {message.analysis.isSafe ? (
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          ) : (
                            <AlertTriangle className="w-4 h-4 text-orange-600" />
                          )}
                          <Badge variant={message.analysis.isSafe ? "default" : "destructive"} className="text-xs">
                            {message.analysis.confidence}% confiance
                          </Badge>
                        </div>
                        <div className="text-xs space-y-1">
                          {message.analysis.suggestions?.map((suggestion, index) => (
                            <div key={index} className="flex items-start gap-1">
                              <span className="text-gray-600">•</span>
                              <span className="text-gray-700">{suggestion}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    <p className="text-xs opacity-70 mt-1">{message.timestamp}</p>
                  </div>
                </div>
              ))}

              {isAnalyzing && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 p-3 rounded-lg">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 animate-spin text-emerald-500" />
                      <span className="text-sm text-gray-600">Analyse en cours...</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </CardContent>

          <div className="p-4 border-t">
            <div className="flex gap-2">
              <Input
                placeholder="Tapez votre message à vérifier..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                disabled={isAnalyzing}
                className="flex-1"
              />
              <Button
                onClick={handleSendMessage}
                disabled={isAnalyzing || !inputMessage.trim()}
                className="bg-emerald-500 hover:bg-emerald-600"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">Testez vos messages avant de les publier</p>
          </div>
        </>
      )}
    </Card>
  )
}
