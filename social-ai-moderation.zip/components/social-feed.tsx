"use client"

import { useState } from "react"
import { PostCard } from "@/components/post-card"
import { CreatePost } from "@/components/create-post"

// Données de démonstration
const initialPosts = [
  {
    id: 1,
    author: "Marie Dubois",
    avatar: "/woman-profile.png",
    timestamp: "Il y a 2h",
    content: "Excited to share my latest AI project! Working on ethical machine learning solutions 🤖",
    likes: 23,
    comments: [
      {
        id: 1,
        author: "Jean Martin",
        avatar: "/man-profile.png",
        content: "Totalement d'accord ! L'IA éthique est l'avenir.",
        timestamp: "Il y a 1h",
        isModerated: false,
      },
      {
        id: 2,
        author: "Sophie Laurent",
        avatar: "/diverse-person-profiles.png",
        content: "Très intéressant ! Peux-tu partager plus de détails ?",
        timestamp: "Il y a 45min",
        isModerated: false,
      },
      {
        id: 3,
        author: "Thomas Dubois",
        avatar: "/man-profile.png",
        content: "Bravo pour ce projet innovant !",
        timestamp: "Il y a 30min",
        isModerated: false,
      },
      {
        id: 4,
        author: "Emma Wilson",
        avatar: "/woman-profile.png",
        content: "L'IA éthique est un sujet passionnant, merci pour le partage !",
        timestamp: "Il y a 15min",
        isModerated: false,
      },
      {
        id: 5,
        author: "Lucas Martin",
        avatar: "/diverse-person-profiles.png",
        content: "Hâte de voir les résultats de tes recherches !",
        timestamp: "Il y a 10min",
        isModerated: false,
      },
    ],
  },
  {
    id: 2,
    author: "Alex Martin",
    avatar: "/diverse-person-profiles.png",
    timestamp: "Il y a 4h",
    content: "Great discussion about sustainable technology today. The future looks bright! 🌱",
    likes: 45,
    comments: [
      {
        id: 1,
        author: "Marie Dubois",
        avatar: "/woman-profile.png",
        content: "Sustainability and tech go hand in hand.",
        timestamp: "Il y a 3h",
        isModerated: false,
      },
      {
        id: 2,
        author: "Pierre Durand",
        avatar: "/man-profile.png",
        content: "Très inspirant ! Continuez comme ça.",
        timestamp: "Il y a 2h",
        isModerated: false,
      },
      {
        id: 3,
        author: "Claire Moreau",
        avatar: "/woman-profile.png",
        content: "J'aimerais en savoir plus sur vos projets durables.",
        timestamp: "Il y a 1h30",
        isModerated: false,
      },
      {
        id: 4,
        author: "Antoine Leroy",
        avatar: "/diverse-person-profiles.png",
        content: "La technologie verte est l'avenir !",
        timestamp: "Il y a 1h",
        isModerated: false,
      },
      {
        id: 5,
        author: "Isabelle Petit",
        avatar: "/woman-profile.png",
        content: "Merci pour cette réflexion importante.",
        timestamp: "Il y a 45min",
        isModerated: false,
      },
      {
        id: 6,
        author: "Nicolas Blanc",
        avatar: "/man-profile.png",
        content: "Innovation et durabilité, le combo parfait !",
        timestamp: "Il y a 30min",
        isModerated: false,
      },
      {
        id: 7,
        author: "Camille Rousseau",
        avatar: "/diverse-person-profiles.png",
        content: "Très bonne initiative, bravo !",
        timestamp: "Il y a 20min",
        isModerated: false,
      },
      {
        id: 8,
        author: "Julien Fabre",
        avatar: "/man-profile.png",
        content: "L'avenir est entre de bonnes mains avec des projets comme le vôtre.",
        timestamp: "Il y a 15min",
        isModerated: false,
      },
      {
        id: 9,
        author: "Léa Girard",
        avatar: "/woman-profile.png",
        content: "Continuez à inspirer la communauté !",
        timestamp: "Il y a 10min",
        isModerated: false,
      },
      {
        id: 10,
        author: "Maxime Roux",
        avatar: "/diverse-person-profiles.png",
        content: "Hâte de voir les prochaines innovations !",
        timestamp: "Il y a 5min",
        isModerated: false,
      },
      {
        id: 11,
        author: "Sarah Bonnet",
        avatar: "/woman-profile.png",
        content: "Merci pour cette vision positive de l'avenir !",
        timestamp: "Il y a 2min",
        isModerated: false,
      },
      {
        id: 12,
        author: "David Mercier",
        avatar: "/man-profile.png",
        content: "Excellent travail, continuez ainsi !",
        timestamp: "Il y a 1min",
        isModerated: false,
      },
    ],
  },
]

export function SocialFeed() {
  const [posts, setPosts] = useState(initialPosts)

  const handleNewPost = (content: string) => {
    const newPost = {
      id: posts.length + 1,
      author: "Vous",
      avatar: "/user-profile-illustration.png",
      timestamp: "À l'instant",
      content,
      likes: 0,
      comments: [],
    }
    setPosts([newPost, ...posts])
  }

  const handleNewComment = (postId: number, content: string, isModerated: boolean) => {
    setPosts(
      posts.map((post) => {
        if (post.id === postId) {
          const newComment = {
            id: post.comments.length + 1,
            author: "Vous",
            avatar: "/user-profile-illustration.png",
            content,
            timestamp: "À l'instant",
            isModerated,
          }
          return {
            ...post,
            comments: [...post.comments, newComment],
          }
        }
        return post
      }),
    )
  }

  return (
    <div className="space-y-6">
      <CreatePost onSubmit={handleNewPost} />
      {posts.map((post) => (
        <PostCard key={post.id} post={post} onComment={handleNewComment} />
      ))}
    </div>
  )
}
