"use client"

import { Users, Sparkles, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"
import Link from "next/link"
import { usePathname } from "next/navigation"

export function Header() {
  const pathname = usePathname()

  return (
    <header className="border-b bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <div className="relative">
              <Image
                src="/safechat-logo.jpg"
                alt="SafeChat Logo"
                width={32}
                height={32}
                className="animate-pulse-green rounded-lg"
              />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">SafeChat</h1>
              <p className="text-xs text-gray-600 hidden sm:block">Modération IA</p>
            </div>
          </Link>

          <Badge
            variant="secondary"
            className="hidden md:flex items-center gap-1.5 bg-emerald-100 text-emerald-700 border-emerald-200"
          >
            <Sparkles className="h-3 w-3" />
            <span className="text-xs font-medium">IA Active</span>
          </Badge>
        </div>

        <div className="flex items-center gap-3">
          <Link href="/community">
            <Button
              variant={pathname === "/community" ? "default" : "ghost"}
              size="sm"
              className={`hidden sm:flex ${pathname === "/community" ? "bg-emerald-500 hover:bg-emerald-600" : ""}`}
            >
              <Users className="h-4 w-4 mr-2" />
              Communauté
            </Button>
          </Link>

          <Link href="/profile">
            <Button
              variant={pathname === "/profile" ? "default" : "outline"}
              size="sm"
              className={
                pathname === "/profile" ? "bg-emerald-500 hover:bg-emerald-600 text-white border-emerald-500" : ""
              }
            >
              <User className="h-4 w-4 mr-2 sm:mr-2" />
              <span className="hidden sm:inline">Profil</span>
            </Button>
          </Link>

          <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
            <span className="hidden sm:inline">Nouveau Post</span>
            <span className="sm:hidden">+</span>
          </Button>
        </div>
      </div>
    </header>
  )
}
