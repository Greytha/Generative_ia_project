"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Shield, AlertTriangle, Send } from "lucide-react"

interface Comment {
  id: number
  author: string
  avatar: string
  content: string
  timestamp: string
  isModerated: boolean
}

interface CommentSectionProps {
  postId: number
  comments: Comment[]
  onComment: (postId: number, content: string, isModerated: boolean) => void
}

export function CommentSection({ postId, comments, onComment }: CommentSectionProps) {
  const [newComment, setNewComment] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const analyzeComment = async (text: string) => {
    // Simulation de l'analyse IA basée sur votre modèle
    const toxicKeywords = ["hate", "stupid", "idiot", "kill", "die", "worst", "terrible", "awful"]
    const lowerText = text.toLowerCase()

    // Simulation simple - dans la vraie app, vous appelleriez votre API Python
    const hasToxicContent = toxicKeywords.some((keyword) => lowerText.includes(keyword))
    const toxicityScore = hasToxicContent ? 0.8 : Math.random() * 0.3

    return {
      isModerated: toxicityScore > 0.6,
      score: toxicityScore,
      emotion: hasToxicContent ? "anger" : "neutral",
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newComment.trim()) return

    setIsAnalyzing(true)

    // Simulation du délai d'analyse
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const analysis = await analyzeComment(newComment)

    onComment(postId, newComment, analysis.isModerated)
    setNewComment("")
    setIsAnalyzing(false)
  }

  return (
    <div className="space-y-4 pt-4 border-t">
      {/* Commentaires existants */}
      {comments.map((comment) => (
        <div key={comment.id} className="flex gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={comment.avatar || "/placeholder.svg"} alt={comment.author} />
            <AvatarFallback>{comment.author.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1 space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-medium text-sm">{comment.author}</span>
              <span className="text-xs text-muted-foreground">{comment.timestamp}</span>
              {comment.isModerated && (
                <div className="flex items-center gap-1">
                  <Shield className="h-3 w-3 text-primary" />
                  <span className="text-xs text-primary">Modéré</span>
                </div>
              )}
            </div>
            {comment.isModerated ? (
              <Alert className="py-2">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-sm">
                  Ce commentaire a été filtré par notre IA de modération pour contenu potentiellement inapproprié.
                </AlertDescription>
              </Alert>
            ) : (
              <p className="text-sm text-card-foreground">{comment.content}</p>
            )}
          </div>
        </div>
      ))}

      {/* Nouveau commentaire */}
      <form onSubmit={handleSubmit} className="flex gap-3">
        <Avatar className="h-8 w-8">
          <AvatarImage src="/user-profile-illustration.png" alt="Vous" />
          <AvatarFallback>V</AvatarFallback>
        </Avatar>
        <div className="flex-1 space-y-2">
          <Textarea
            placeholder="Écrivez un commentaire..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="min-h-[60px] resize-none"
            disabled={isAnalyzing}
          />
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              <Shield className="h-3 w-3 text-primary" />
              <span>Modération IA active</span>
            </div>
            <Button type="submit" size="sm" disabled={!newComment.trim() || isAnalyzing}>
              {isAnalyzing ? (
                <>
                  <div className="animate-spin h-3 w-3 border border-current border-t-transparent rounded-full mr-2" />
                  Analyse...
                </>
              ) : (
                <>
                  <Send className="h-3 w-3 mr-1" />
                  Commenter
                </>
              )}
            </Button>
          </div>
        </div>
      </form>
    </div>
  )
}
