"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MapPin, Calendar, Shield, MessageCircle, Heart, Share2, Settings, Edit3 } from "lucide-react"
import { Header } from "@/components/header"
import AIAssistantChat from "@/components/ai-assistant-chat"

export default function ProfilePage() {
  const [activeTab, setActiveTab] = useState("posts")
  const [isChatOpen, setIsChatOpen] = useState(false)

  const userStats = {
    posts: 42,
    followers: 1234,
    following: 567,
    safetyScore: 98,
  }

  const userPosts = [
    {
      id: 1,
      content: "Excited to share my latest project! Working on sustainable tech solutions 🌱",
      timestamp: "2h ago",
      likes: 23,
      comments: 5,
      shares: 2,
      isVerified: true,
    },
    {
      id: 2,
      content: "Great discussion today about AI ethics. Thanks everyone for the thoughtful comments!",
      timestamp: "1d ago",
      likes: 45,
      comments: 12,
      shares: 8,
      isVerified: true,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      <Header />

      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Profile Header */}
        <Card className="mb-8 border-0 shadow-lg bg-white/80 backdrop-blur-sm">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start gap-6">
              <div className="relative">
                <Avatar className="w-32 h-32 border-4 border-emerald-200">
                  <AvatarImage src="/woman-profile.png" alt="Profile" />
                  <AvatarFallback className="bg-emerald-100 text-emerald-700 text-2xl">SA</AvatarFallback>
                </Avatar>
                <Badge className="absolute -bottom-2 -right-2 bg-emerald-500 hover:bg-emerald-600">
                  <Shield className="w-3 h-3 mr-1" />
                  Vérifié
                </Badge>
              </div>

              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h1 className="text-3xl font-bold text-gray-900">Sarah Anderson</h1>
                  <Badge variant="outline" className="text-emerald-600 border-emerald-200">
                    <Shield className="w-3 h-3 mr-1" />
                    Score: {userStats.safetyScore}%
                  </Badge>
                </div>

                <p className="text-gray-600 mb-4 text-lg">
                  Développeuse passionnée par l'IA éthique et les technologies durables 🌱
                </p>

                <div className="flex items-center gap-4 text-sm text-gray-500 mb-6">
                  <div className="flex items-center gap-1">
                    <MapPin className="w-4 h-4" />
                    Paris, France
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Membre depuis Mars 2024
                  </div>
                </div>

                <div className="flex gap-6 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{userStats.posts}</div>
                    <div className="text-sm text-gray-500">Posts</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{userStats.followers}</div>
                    <div className="text-sm text-gray-500">Abonnés</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-gray-900">{userStats.following}</div>
                    <div className="text-sm text-gray-500">Abonnements</div>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button className="bg-emerald-500 hover:bg-emerald-600">
                    <Edit3 className="w-4 h-4 mr-2" />
                    Modifier le profil
                  </Button>
                  <Button variant="outline">
                    <Settings className="w-4 h-4 mr-2" />
                    Paramètres
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="posts">Mes Posts</TabsTrigger>
            <TabsTrigger value="activity">Activité</TabsTrigger>
            <TabsTrigger value="safety">Sécurité</TabsTrigger>
          </TabsList>

          <TabsContent value="posts" className="space-y-4">
            {userPosts.map((post) => (
              <Card key={post.id} className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <Avatar className="w-10 h-10">
                      <AvatarImage src="/woman-profile.png" alt="Profile" />
                      <AvatarFallback>SA</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-semibold">Sarah Anderson</span>
                        {post.isVerified && (
                          <Badge variant="outline" className="text-emerald-600 border-emerald-200 text-xs">
                            <Shield className="w-3 h-3 mr-1" />
                            Vérifié IA
                          </Badge>
                        )}
                        <span className="text-sm text-gray-500">{post.timestamp}</span>
                      </div>
                      <p className="text-gray-800 mb-4">{post.content}</p>
                      <div className="flex items-center gap-6 text-sm text-gray-500">
                        <button className="flex items-center gap-1 hover:text-red-500 transition-colors">
                          <Heart className="w-4 h-4" />
                          {post.likes}
                        </button>
                        <button className="flex items-center gap-1 hover:text-blue-500 transition-colors">
                          <MessageCircle className="w-4 h-4" />
                          {post.comments}
                        </button>
                        <button className="flex items-center gap-1 hover:text-green-500 transition-colors">
                          <Share2 className="w-4 h-4" />
                          {post.shares}
                        </button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="activity">
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Activité récente</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-emerald-50">
                    <Heart className="w-5 h-5 text-red-500" />
                    <span>
                      Vous avez aimé le post de <strong>Alex Martin</strong>
                    </span>
                    <span className="text-sm text-gray-500 ml-auto">Il y a 2h</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-blue-50">
                    <MessageCircle className="w-5 h-5 text-blue-500" />
                    <span>
                      Vous avez commenté le post de <strong>Marie Dubois</strong>
                    </span>
                    <span className="text-sm text-gray-500 ml-auto">Il y a 4h</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="safety">
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5 text-emerald-500" />
                  Tableau de bord sécurité
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-emerald-50">
                    <div>
                      <h3 className="font-semibold text-emerald-800">Score de sécurité</h3>
                      <p className="text-sm text-emerald-600">Basé sur vos interactions</p>
                    </div>
                    <div className="text-3xl font-bold text-emerald-600">{userStats.safetyScore}%</div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-4 rounded-lg bg-green-50">
                      <h4 className="font-semibold text-green-800 mb-2">Posts vérifiés</h4>
                      <div className="text-2xl font-bold text-green-600">42/42</div>
                      <p className="text-sm text-green-600">100% de vos posts sont sûrs</p>
                    </div>

                    <div className="p-4 rounded-lg bg-blue-50">
                      <h4 className="font-semibold text-blue-800 mb-2">Commentaires modérés</h4>
                      <div className="text-2xl font-bold text-blue-600">0</div>
                      <p className="text-sm text-blue-600">Aucun commentaire signalé</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <AIAssistantChat isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  )
}
