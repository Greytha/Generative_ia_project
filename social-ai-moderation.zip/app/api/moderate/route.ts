import { type NextRequest, NextResponse } from "next/server"
import { spawn } from "child_process"
import path from "path"

export async function POST(request: NextRequest) {
  try {
    const { text, threshold = 0.6, consensus = 2 } = await request.json()

    if (!text || typeof text !== "string") {
      return NextResponse.json({ error: "Texte requis" }, { status: 400 })
    }

    // Appeler le service Python de modération
    const result = await callPythonModerationService({
      text,
      threshold,
      consensus,
    })

    return NextResponse.json(result)
  } catch (error) {
    console.error("Erreur lors de la modération:", error)

    // Fallback vers une analyse simple en cas d'erreur
    const fallbackResult = await fallbackModeration(await request.json())
    return NextResponse.json(fallbackResult)
  }
}

async function callPythonModerationService(data: {
  text: string
  threshold: number
  consensus: number
}): Promise<any> {
  return new Promise((resolve, reject) => {
    const scriptPath = path.join(process.cwd(), "scripts", "ai-moderation-service.py")
    const pythonProcess = spawn("python3", [scriptPath])

    let output = ""
    let errorOutput = ""

    // Envoyer les données au script Python
    pythonProcess.stdin.write(JSON.stringify(data))
    pythonProcess.stdin.end()

    pythonProcess.stdout.on("data", (data) => {
      output += data.toString()
    })

    pythonProcess.stderr.on("data", (data) => {
      errorOutput += data.toString()
    })

    pythonProcess.on("close", (code) => {
      if (code === 0) {
        try {
          const result = JSON.parse(output)
          resolve(result)
        } catch (parseError) {
          console.error("Erreur parsing JSON:", parseError)
          console.error("Output:", output)
          reject(new Error("Erreur parsing de la réponse Python"))
        }
      } else {
        console.error("Erreur Python:", errorOutput)
        reject(new Error(`Script Python terminé avec le code ${code}`))
      }
    })

    // Timeout de 30 secondes
    setTimeout(() => {
      pythonProcess.kill()
      reject(new Error("Timeout du script Python"))
    }, 30000)
  })
}

// Fonction de secours si Python ne fonctionne pas
async function fallbackModeration(data: { text: string }) {
  const { text } = data

  // Analyse simple basée sur des mots-clés (comme backup)
  const toxicKeywords = [
    "hate",
    "stupid",
    "idiot",
    "kill",
    "die",
    "worst",
    "terrible",
    "awful",
    "shut up",
    "loser",
    "pathetic",
    "disgusting",
    "worthless",
  ]

  const lowerText = text.toLowerCase()
  const toxicMatches = toxicKeywords.filter((keyword) => lowerText.includes(keyword))
  const toxicityScore = toxicMatches.length > 0 ? 0.8 : 0.2
  const shouldBlock = toxicityScore > 0.6

  return {
    text,
    toxicity: {
      score: toxicityScore,
      label: shouldBlock ? "toxic" : "non-toxic",
      shouldBlock,
      details: [["fallback-analysis", toxicityScore]],
    },
    emotion: {
      label: "neutral",
      score: 0.5,
    },
    moderation: {
      blocked: shouldBlock,
      reason: shouldBlock ? "Contenu potentiellement toxique (analyse de secours)" : null,
      confidence: toxicityScore,
      consensus: toxicMatches.length,
      fallback: true,
    },
  }
}
