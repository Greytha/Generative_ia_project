"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Search, Users, MessageCircle, TrendingUp, Shield, Plus, Star } from "lucide-react"
import { Header } from "@/components/header"
import AIAssistantChat from "@/components/ai-assistant-chat"

export default function CommunityPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [isChatOpen, setIsChatOpen] = useState(false)

  const communities = [
    {
      id: 1,
      name: "IA & Éthique",
      description: "Discussions sur l'intelligence artificielle responsable et éthique",
      members: 2847,
      posts: 156,
      category: "Technologie",
      isVerified: true,
      trending: true,
      image: "🤖",
    },
    {
      id: 2,
      name: "Développement Durable",
      description: "Solutions tech pour un avenir plus vert",
      members: 1923,
      posts: 89,
      category: "Environnement",
      isVerified: true,
      trending: false,
      image: "🌱",
    },
    {
      id: 3,
      name: "Startups & Innovation",
      description: "Partage d'expériences entrepreneuriales",
      members: 3421,
      posts: 234,
      category: "Business",
      isVerified: true,
      trending: true,
      image: "🚀",
    },
    {
      id: 4,
      name: "Design UX/UI",
      description: "Créativité et expérience utilisateur",
      members: 1567,
      posts: 78,
      category: "Design",
      isVerified: false,
      trending: false,
      image: "🎨",
    },
  ]

  const trendingTopics = [
    { name: "IA Générative", posts: 45 },
    { name: "Modération Automatique", posts: 32 },
    { name: "Tech Éthique", posts: 28 },
    { name: "Développement Durable", posts: 24 },
  ]

  const recentActivity = [
    {
      user: "Marie Dubois",
      action: "a créé un nouveau post dans",
      community: "IA & Éthique",
      time: "Il y a 2h",
    },
    {
      user: "Alex Martin",
      action: "a rejoint la communauté",
      community: "Startups & Innovation",
      time: "Il y a 4h",
    },
    {
      user: "Sophie Laurent",
      action: "a commenté dans",
      community: "Design UX/UI",
      time: "Il y a 6h",
    },
  ]

  const filteredCommunities = communities.filter(
    (community) =>
      community.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      community.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Header */}
      <Header />

      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Search and Filters */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardContent className="p-6">
                <div className="flex gap-4 items-center">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                    <Input
                      placeholder="Rechercher une communauté..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Button className="bg-emerald-500 hover:bg-emerald-600">
                    <Plus className="w-4 h-4 mr-2" />
                    Créer
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Communities Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredCommunities.map((community) => (
                <Card
                  key={community.id}
                  className="border-0 shadow-md bg-white/80 backdrop-blur-sm hover:shadow-lg transition-shadow cursor-pointer"
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="text-3xl">{community.image}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{community.name}</h3>
                          {community.isVerified && (
                            <Badge variant="outline" className="text-emerald-600 border-emerald-200 text-xs">
                              <Shield className="w-3 h-3 mr-1" />
                              Vérifié
                            </Badge>
                          )}
                          {community.trending && (
                            <Badge className="bg-orange-100 text-orange-600 hover:bg-orange-200 text-xs">
                              <TrendingUp className="w-3 h-3 mr-1" />
                              Tendance
                            </Badge>
                          )}
                        </div>

                        <p className="text-gray-600 text-sm mb-4">{community.description}</p>

                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-4 text-sm text-gray-500">
                            <div className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {community.members.toLocaleString()}
                            </div>
                            <div className="flex items-center gap-1">
                              <MessageCircle className="w-4 h-4" />
                              {community.posts}
                            </div>
                          </div>
                          <Badge variant="secondary" className="text-xs">
                            {community.category}
                          </Badge>
                        </div>

                        <Button className="w-full mt-4 bg-emerald-500 hover:bg-emerald-600">Rejoindre</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending Topics */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-orange-500" />
                  Sujets tendance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {trendingTopics.map((topic, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                        <span className="font-medium">{topic.name}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {topic.posts} posts
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-500" />
                  Activité récente
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start gap-3">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback className="bg-emerald-100 text-emerald-700 text-xs">
                          {activity.user
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="text-sm">
                          <span className="font-medium">{activity.user}</span> {activity.action}{" "}
                          <span className="font-medium text-emerald-600">{activity.community}</span>
                        </p>
                        <p className="text-xs text-gray-500">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Community Stats */}
            <Card className="border-0 shadow-md bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Statistiques</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Total communautés</span>
                    <span className="font-bold text-emerald-600">24</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Membres actifs</span>
                    <span className="font-bold text-emerald-600">12.5k</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Posts aujourd'hui</span>
                    <span className="font-bold text-emerald-600">156</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* AI Assistant Chat */}
      <AIAssistantChat isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  )
}
