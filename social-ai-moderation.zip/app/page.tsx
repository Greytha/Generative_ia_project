"use client"

import { Header } from "@/components/header"
import { SocialFeed } from "@/components/social-feed"
import { Card, CardContent } from "@/components/ui/card"
import AIAssistantChat from "@/components/ai-assistant-chat"
import { useState } from "react"

export default function Home() {
  const [isChatOpen, setIsChatOpen] = useState(false)

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      <Header />

      <main className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Bienvenue sur SafeChat</h2>
          <p className="text-gray-600">Votre réseau social protégé par une IA de modération avancée</p>
        </div>

        <SocialFeed />

        {/* AI Status */}
        <Card className="mt-8 border-0 shadow-sm bg-emerald-50/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse"></div>
              <div>
                <p className="font-medium text-emerald-800">Modération IA Active</p>
                <p className="text-sm text-emerald-600">
                  Votre modèle fine-tuné analyse tous les contenus en temps réel
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      <AIAssistantChat isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />
    </div>
  )
}
